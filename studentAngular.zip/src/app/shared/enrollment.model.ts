export class Enrollment {
    EnrollmentID:number;
    CourseID:number;
    StudentID:number;
    
}
